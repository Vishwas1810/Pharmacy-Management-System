-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2022 at 08:04 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Comp_Id` varchar(20) DEFAULT NULL,
  `Comp_Name` varchar(20) NOT NULL,
  `Address` varchar(20) DEFAULT NULL,
  `Phone` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Comp_Id`, `Comp_Name`, `Address`, `Phone`) VALUES
('Cip56', 'Cipla', 'Udupi', 9867854334),
('GlemM857', 'GlenMark', 'Delli', 8907865676),
('Lup123', 'Lupin', 'Mumbai', 9807657456);

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE `drugs` (
  `Barcode` varchar(20) NOT NULL,
  `Drug_Name` varchar(20) DEFAULT NULL,
  `Comp_Name` varchar(20) DEFAULT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Dose` varchar(10) DEFAULT NULL,
  `Prod_Date` date DEFAULT NULL,
  `Exp_Date` date DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`Barcode`, `Drug_Name`, `Comp_Name`, `Type`, `Dose`, `Prod_Date`, `Exp_Date`, `Quantity`, `Price`) VALUES
('Med1234', 'Metacin', 'Cipla', 'Pills', '500Mg', '2021-12-30', '2022-05-31', 8, 600),
('Med6573', 'Kevzara', 'Cipla', 'Drops', '200Mg', '2019-01-07', '2022-01-04', 5, 450);

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

CREATE TABLE `login_details` (
  `UserId` varchar(20) NOT NULL,
  `UserName` varchar(20) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `LoginAs` char(1) DEFAULT 'U',
  `Address` varchar(20) NOT NULL DEFAULT 'India',
  `Email_Id` varchar(20) DEFAULT NULL,
  `Phone` bigint(20) DEFAULT NULL,
  `Salary` float DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`UserId`, `UserName`, `Password`, `LoginAs`, `Address`, `Email_Id`, `Phone`, `Salary`) VALUES
('Uttam108', 'Uttam', 'uttam@108', 'E', 'Manglore', 'uttam@gmail.com', 8970665439, 45000),
('Varun113', 'Varun', 'varun@113', 'U', 'India', 'varun@gmail.com', 9807687341, 0),
('Vishwas123', 'Vishwas Prabhu', 'vp@123', 'A', 'Udupi', 'admin@gmail.com', 9867854334, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `Barcode` varchar(20) NOT NULL,
  `Drug_Name` varchar(20) DEFAULT NULL,
  `Comp_Name` varchar(20) NOT NULL,
  `Type` varchar(20) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `Total_Amt` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `Sale_Id` int(11) NOT NULL DEFAULT 1,
  `Emp_Id` varchar(20) NOT NULL,
  `Emp_Name` varchar(20) NOT NULL,
  `Drug_Id` varchar(20) NOT NULL,
  `Comp_Name` varchar(20) NOT NULL,
  `Customer_Name` varchar(20) NOT NULL,
  `Cust_EmailId` varchar(255) NOT NULL,
  `Sell_Date` date NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Total_Amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Sale_Id`, `Emp_Id`, `Emp_Name`, `Drug_Id`, `Comp_Name`, `Customer_Name`, `Cust_EmailId`, `Sell_Date`, `Quantity`, `Total_Amount`) VALUES
(1, 'Uttam108', 'Uttam', 'Med1234', 'Cipla', 'Vishwas', 'vishuprabhu4321v@gmail.com', '2022-01-30', 2, 120);

--
-- Triggers `sales`
--
DELIMITER $$
CREATE TRIGGER `Employee_Sell` AFTER INSERT ON `sales` FOR EACH ROW INSERT INTO sell_info(Emp_Id,Drug_Id,Subject,Total_Amt,Sell_Date) VALUES(new.Emp_Id,new.Drug_Id,"Drug is Sold",new.Total_Amount,new.Sell_Date)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sell_info`
--

CREATE TABLE `sell_info` (
  `Msg_Id` int(11) NOT NULL,
  `Emp_Id` varchar(20) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Total_Amt` float NOT NULL DEFAULT 0,
  `Sell_Date` date NOT NULL,
  `Drug_Id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sell_info`
--

INSERT INTO `sell_info` (`Msg_Id`, `Emp_Id`, `Subject`, `Total_Amt`, `Sell_Date`, `Drug_Id`) VALUES
(0, 'Uttam108', 'Drug is Sold', 120, '2022-01-30', 'Med1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Comp_Name`);

--
-- Indexes for table `drugs`
--
ALTER TABLE `drugs`
  ADD PRIMARY KEY (`Barcode`),
  ADD KEY `fkDC` (`Comp_Name`);

--
-- Indexes for table `login_details`
--
ALTER TABLE `login_details`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`Barcode`,`Comp_Name`),
  ADD KEY `fkPC` (`Comp_Name`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`Sale_Id`),
  ADD KEY `fkS1` (`Emp_Id`),
  ADD KEY `fkS2` (`Drug_Id`),
  ADD KEY `fkS3` (`Comp_Name`);

--
-- Indexes for table `sell_info`
--
ALTER TABLE `sell_info`
  ADD PRIMARY KEY (`Msg_Id`),
  ADD KEY `fkk1` (`Emp_Id`),
  ADD KEY `fkk2` (`Drug_Id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `drugs`
--
ALTER TABLE `drugs`
  ADD CONSTRAINT `fkDC` FOREIGN KEY (`Comp_Name`) REFERENCES `company` (`Comp_Name`) ON DELETE SET NULL;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `fkPC` FOREIGN KEY (`Comp_Name`) REFERENCES `company` (`Comp_Name`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `fkS1` FOREIGN KEY (`Emp_Id`) REFERENCES `login_details` (`UserId`),
  ADD CONSTRAINT `fkS2` FOREIGN KEY (`Drug_Id`) REFERENCES `drugs` (`Barcode`),
  ADD CONSTRAINT `fkS3` FOREIGN KEY (`Comp_Name`) REFERENCES `company` (`Comp_Name`);

--
-- Constraints for table `sell_info`
--
ALTER TABLE `sell_info`
  ADD CONSTRAINT `fkk1` FOREIGN KEY (`Emp_Id`) REFERENCES `login_details` (`UserId`),
  ADD CONSTRAINT `fkk2` FOREIGN KEY (`Drug_Id`) REFERENCES `drugs` (`Barcode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
